create view v_import_card as
select `access-system-dev`.`import_card`.`id`         AS `id`,
       `access-system-dev`.`import_card`.`auid`       AS `auid`,
       `access-system-dev`.`import_card`.`XH`         AS `XH`,
       `access-system-dev`.`import_card`.`RXFXE`      AS `RXFXE`,
       `access-system-dev`.`import_card`.`ZCRQ`       AS `ZCRQ`,
       `access-system-dev`.`import_card`.`KYXQ`       AS `KYXQ`,
       `access-system-dev`.`import_card`.`XM`         AS `XM`,
       `access-system-dev`.`import_card`.`KHSJ`       AS `KHSJ`,
       `access-system-dev`.`import_card`.`TIMESTAMPS` AS `TIMESTAMPS`,
       `access-system-dev`.`import_card`.`KXLH`       AS `KXLH`,
       `access-system-dev`.`import_card`.`KPZT`       AS `KPZT`,
       `access-system-dev`.`import_card`.`KH`         AS `KH`,
       `access-system-dev`.`import_card`.`SFRZH`      AS `SFRZH`,
       `access-system-dev`.`import_card`.`ROW_ID`     AS `ROW_ID`,
       `access-system-dev`.`import_card`.`creator`    AS `creator`,
       `access-system-dev`.`import_card`.`createTime` AS `createTime`,
       `access-system-dev`.`import_card`.`reviser`    AS `reviser`,
       `access-system-dev`.`import_card`.`reviseTime` AS `reviseTime`,
       `access-system-dev`.`import_card`.`isDel`      AS `isDel`
from `access-system-dev`.`import_card`
where `access-system-dev`.`import_card`.`ROW_ID` in (select max(`access-system-dev`.`import_card`.`ROW_ID`)
                                                     from `access-system-dev`.`import_card`
                                                     group by `access-system-dev`.`import_card`.`XH`);

