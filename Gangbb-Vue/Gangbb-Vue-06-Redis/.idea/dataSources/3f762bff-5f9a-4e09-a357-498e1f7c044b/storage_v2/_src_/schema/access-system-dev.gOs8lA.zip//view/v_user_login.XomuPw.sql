create view v_user_login as
select `access-system-dev`.`base_student`.`id`     AS `id`,
       `access-system-dev`.`base_student`.`number` AS `account`,
       `access-system-dev`.`base_student`.`name`   AS `name`,
       `access-system-dev`.`base_student`.`idCard` AS `idcard`,
       `access-system-dev`.`base_student`.`phone`  AS `phone`,
       '1'                                         AS `userType`
from `access-system-dev`.`base_student`
where (`access-system-dev`.`base_student`.`isDel` = 0)
union
select `access-system-dev`.`base_teacher`.`id`     AS `id`,
       `access-system-dev`.`base_teacher`.`number` AS `account`,
       `access-system-dev`.`base_teacher`.`name`   AS `name`,
       `access-system-dev`.`base_teacher`.`idCard` AS `idCard`,
       `access-system-dev`.`base_teacher`.`phone`  AS `phone`,
       '2'                                         AS `userType`
from `access-system-dev`.`base_teacher`
where (`access-system-dev`.`base_teacher`.`isDel` = 0)
union
select `access-system-dev`.`base_other_person`.`id`     AS `id`,
       `access-system-dev`.`base_other_person`.`phone`  AS `account`,
       `access-system-dev`.`base_other_person`.`name`   AS `name`,
       `access-system-dev`.`base_other_person`.`idCard` AS `idCard`,
       `access-system-dev`.`base_other_person`.`phone`  AS `phone`,
       '3'                                              AS `userType`
from `access-system-dev`.`base_other_person`
where (`access-system-dev`.`base_other_person`.`isDel` = 0);

