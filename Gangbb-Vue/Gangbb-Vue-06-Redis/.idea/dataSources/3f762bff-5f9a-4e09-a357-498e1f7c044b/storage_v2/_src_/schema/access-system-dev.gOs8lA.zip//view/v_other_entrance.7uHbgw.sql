create view v_other_entrance as
select `bop`.`id`             AS `id`,
       `bop`.`type`           AS `type`,
       `bop`.`name`           AS `name`,
       `bop`.`sex`            AS `sex`,
       `bop`.`idCard`         AS `idCard`,
       `bop`.`isDependents`   AS `isDependents`,
       `bop`.`relation`       AS `relation`,
       `bop`.`relationNumber` AS `relationNumber`,
       `bop`.`phone`          AS `phone`,
       `bop`.`carNumber`      AS `carNumber`,
       `bop`.`pictureId`      AS `pictureId`,
       `bop`.`pictureUrl`     AS `pictureUrl`,
       `bop`.`address`        AS `address`,
       `bop`.`companyName`    AS `companyName`,
       `bop`.`status`         AS `status`,
       `bop`.`dahuaId`        AS `dahuaId`,
       `bop`.`academyCode`    AS `academyCode`,
       `bop`.`creator`        AS `creator`,
       `bop`.`createTime`     AS `createTime`,
       `bop`.`reviser`        AS `reviser`,
       `bop`.`reviseTime`     AS `reviseTime`,
       `bop`.`isDel`          AS `isDel`,
       `b`.`name`             AS `departmentName`,
       `b`.`dahuaId`          AS `departmentDahuaId`,
       `b`.`shortName`        AS `departmentShorName`,
       `c`.`id`               AS `cardId`,
       `c`.`cardSerial`       AS `cardSerial`,
       `c`.`accountTime`      AS `accountTime`,
       `c`.`dayLimit`         AS `dayLimit`,
       `c`.`effective`        AS `effective`,
       `c`.`cardNumber`       AS `cardNumber`,
       `c`.`payTime`          AS `payTime`,
       `c`.`officeNumber`     AS `officeNumber`,
       `c`.`userType`         AS `userType`,
       `c`.`realCardNumber`   AS `realCardNumber`
from ((`access-system-dev`.`base_other_person` `bop` join `access-system-dev`.`base_academy` `b`)
         join `access-system-dev`.`base_card` `c`)
where ((convert(`b`.`code` using utf8mb4) = convert(`bop`.`academyCode` using utf8mb4)) and (`bop`.`isDel` = 0) and
       (`b`.`isDel` = 0) and (convert(`bop`.`idCard` using utf8mb4) = `c`.`idCard`) and
       (convert(`bop`.`phone` using utf8mb4) = `c`.`officeNumber`) and
       (convert(`bop`.`name` using utf8mb4) = `c`.`name`))
order by `bop`.`createTime` desc;

