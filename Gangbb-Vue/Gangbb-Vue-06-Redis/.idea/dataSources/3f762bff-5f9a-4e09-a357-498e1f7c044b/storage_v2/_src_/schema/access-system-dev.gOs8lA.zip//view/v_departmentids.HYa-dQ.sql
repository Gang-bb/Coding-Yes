create view v_departmentids as
select `s`.`id` AS `id`, ifnull(`c`.`dahuaId`, ifnull(`m`.`dahuaId`, `a`.`dahuaId`)) AS `departId`
from (((`access-system-dev`.`base_student` `s` left join `access-system-dev`.`base_academy` `a` on ((`s`.`academyCode` = `a`.`code`))) left join `access-system-dev`.`base_major` `m` on ((`s`.`majorCode` = `m`.`code`)))
         left join `access-system-dev`.`base_class` `c` on ((`s`.`classCode` = `c`.`code`)))
where ((`s`.`isDel` = 0) and (`a`.`isDel` = 0) and (`m`.`isDel` = 0) and (`c`.`isDel` = 0))
union
select `t`.`id` AS `id`, `a`.`dahuaId` AS `departId`
from (`access-system-dev`.`base_teacher` `t`
         join `access-system-dev`.`base_academy` `a`)
where ((`t`.`departmentCode` = `a`.`code`) and (`a`.`isDel` = 0) and (`t`.`isDel` = 0))
union
select `p`.`id` AS `id`, `a`.`dahuaId` AS `departId`
from (`access-system-dev`.`base_other_person` `p`
         join `access-system-dev`.`base_academy` `a`)
where ((`p`.`academyCode` = `a`.`code`) and (`p`.`isDel` = 0) and (`a`.`isDel` = 0))
union
select `m`.`applyId` AS `id`, `a`.`dahuaId` AS `departId`
from (`access-system-dev`.`apply_message` `m`
         join `access-system-dev`.`base_academy` `a`)
where ((convert(`m`.`contactPersonDepartmentCode` using utf8mb4) = `a`.`code`) and (`m`.`isDel` = 0) and
       (`a`.`isDel` = 0) and (`m`.`personType` > 5) and (`m`.`finishStatus` = 0));

