create view v_getnextrealcardnumber as
select cast((ifnull(max(`access-system-dev`.`base_student`.`cardNumber`), 11111110) +
             1) as char charset utf8mb4) AS `cardNumber`,
       '1'                               AS `personType`
from `access-system-dev`.`base_student`
where ((`access-system-dev`.`base_student`.`cardNumber` like '1111%') and
       (`access-system-dev`.`base_student`.`isDel` = 0))
union
select cast((ifnull(max(`access-system-dev`.`base_teacher`.`cardNumber`), 22222220) +
             1) as char charset utf8mb4) AS `cardNumber`,
       '2'                               AS `personType`
from `access-system-dev`.`base_teacher`
where ((`access-system-dev`.`base_teacher`.`cardNumber` like '2222%') and
       (`access-system-dev`.`base_teacher`.`isDel` = 0))
union
select cast((ifnull(max(`access-system-dev`.`base_other_person`.`cardNumber`), 33333330) +
             1) as char charset utf8mb4) AS `cardNumber`,
       '3'                               AS `personType`
from `access-system-dev`.`base_other_person`
where ((`access-system-dev`.`base_other_person`.`cardNumber` like '3333%') and
       (`access-system-dev`.`base_other_person`.`isDel` = 0));

