create view v_apply_user as
select `s`.`id`                        AS `id`,
       `s`.`number`                    AS `number`,
       `s`.`name`                      AS `name`,
       `s`.`sex`                       AS `sex`,
       `s`.`phone`                     AS `phone`,
       `s`.`idCard`                    AS `idCard`,
       `s`.`academyCode`               AS `academyCode`,
       `s`.`majorCode`                 AS `majorCode`,
       `s`.`classCode`                 AS `classCode`,
       `s`.`type`                      AS `studentType`,
       `s`.`pictureUrl`                AS `pictureUrl`,
       `s`.`dahuaId`                   AS `dahuaId`,
       `s`.`cardNumber`                AS `cardNumber`,
       `s`.`dahuaCardId`               AS `dahuaCardId`,
       from_unixtime(`s`.`createTime`) AS `createTimeStr`,
       1                               AS `userType`
from `access-system-dev`.`base_student` `s`
where (`s`.`isDel` = 0)
union
select `t`.`id`                        AS `id`,
       `t`.`number`                    AS `number`,
       `t`.`name`                      AS `name`,
       `t`.`sex`                       AS `sex`,
       `t`.`phone`                     AS `phone`,
       `t`.`idCard`                    AS `idCard`,
       `t`.`departmentCode`            AS `departmentCode`,
       ''                              AS `majorCode`,
       ''                              AS `classCode`,
       ''                              AS `studentType`,
       `t`.`pictureUrl`                AS `pictureUrl`,
       `t`.`dahuaId`                   AS `dahuaId`,
       `t`.`cardNumber`                AS `cardNumber`,
       `t`.`dahuaCardId`               AS `dahuaCardId`,
       from_unixtime(`t`.`createTime`) AS `createTimeStr`,
       2                               AS `userType`
from `access-system-dev`.`base_teacher` `t`
where (`t`.`isDel` = 0)
union
select `p`.`id`                        AS `id`,
       `p`.`number`                    AS `number`,
       `p`.`name`                      AS `name`,
       `p`.`sex`                       AS `sex`,
       `p`.`phone`                     AS `phone`,
       `p`.`idCard`                    AS `idCard`,
       `p`.`academyCode`               AS `academyCode`,
       ''                              AS `majorCode`,
       ''                              AS `classCode`,
       ''                              AS `studentType`,
       `p`.`pictureUrl`                AS `pictureUrl`,
       `p`.`dahuaId`                   AS `dahuaId`,
       `p`.`cardNumber`                AS `cardNumber`,
       `p`.`dahuaCardId`               AS `dahuaCardId`,
       from_unixtime(`p`.`createTime`) AS `createTimeStr`,
       (`p`.`type` + 2)                AS `userType`
from `access-system-dev`.`base_other_person` `p`
where (`p`.`isDel` = 0);

